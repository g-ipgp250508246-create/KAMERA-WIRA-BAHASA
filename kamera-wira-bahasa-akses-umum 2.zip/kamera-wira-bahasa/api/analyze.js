import { GoogleGenAI } from "@google/genai";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Hanya kaedah POST dibenarkan." });
  }

  try {
    const { imageBase64, mimeType } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: "Tiada data gambar diterima." });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: "Kunci API pelayan (GEMINI_API_KEY) belum dikonfigurasikan. Sila tetapkannya pada tetapan hosting anda."
      });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    const prompt = `
Anda ialah enjin analisis visual pintar untuk aplikasi pendidikan "Kamera Wira Bahasa" (maskot: Spider Bahasa).
Analisis gambar ini secara menyeluruh (haiwan, tumbuhan, buah-buahan, sayur-sayuran, makanan, minuman, manusia, aktiviti harian, anggota badan, pakaian, aksesori, peralatan sekolah, peralatan rumah, kenderaan, alam semula jadi, tempat/persekitaran, ilustrasi, lukisan, foto sebenar, atau gabungan pelbagai objek).

PERATURAN KETAT:
1. Jika terdapat beberapa objek, analisis gabungan, ciri dan hubungan antara objek tersebut. Jangan ambil satu objek secara rawak.
2. JANGAN sesekali mereka-reka peribahasa baharu atau memberikan jawapan yang tidak sahih. Hanya cadangkan peribahasa Bahasa Melayu yang sahih dan wujud dalam kurikulum/rujukan rasmi.
3. Jika gambar terlalu kabur, gelap, atau tidak dapat dikenal pasti dengan yakin, tetapkan status kepada "TIDAK_JELAS".
4. Jika gambar berjaya dikenal pasti tetapi tiada peribahasa yang benar-benar sesuai, tetapkan status kepada "TIADA_PADANAN" dan berikan kata kunci objek sahaja.
5. Susun senarai padanan daripada skor kesesuaian paling relevan kepada yang kurang relevan.

Pulangkan jawapan dalam format JSON tulen sahaja (tanpa blok markdown \`\`\`json):
{
  "status": "BERJAYA | TIADA_PADANAN | TIDAK_JELAS",
  "tahap_keyakinan": 0.0,
  "ringkasan_visual": "Penerangan ringkas tentang objek utama, objek sampingan dan situasi dalam gambar (Bahasa Melayu)",
  "objek_utama": ["objek 1"],
  "objek_sampingan": ["objek sampingan 1"],
  "situasi": "Aktiviti atau situasi yang berlaku",
  "kata_kunci": ["kata kunci 1", "kata kunci 2", "nilai murni"],
  "padanan": [
    {
      "peribahasa": "Teks peribahasa sahih",
      "kaedah": "Padanan Objek | Padanan Situasi & Maksud",
      "skor": 95,
      "maksud": "Maksud rasmi peribahasa",
      "contoh_ayat": "Contoh ayat lengkap yang sesuai untuk murid sekolah",
      "kaitan_gambar": "Penjelasan bagaimana objek atau situasi dalam gambar berkait dengan peribahasa ini"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        prompt,
        {
          inlineData: {
            data: imageBase64,
            mimeType: mimeType || "image/jpeg",
          },
        },
      ],
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsedData = JSON.parse(response.text);
    return res.status(200).json(parsedData);
  } catch (error) {
    console.error("Ralat API Gemini:", error);
    return res.status(500).json({
      error: "Gagal menganalisis gambar buat sementara waktu. Sila cuba lagi.",
    });
  }
}
